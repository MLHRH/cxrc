
//layout: top,topCenter,topLeft,topRight,center,centerLeft,centerRight,bottom,bottomCenter,bottomLeft,bottomRight
//type: alert,information,error,warning,notification
//text: your message
function generatenoty(layout,text,type) {
  	var n = noty({
  		text: text,
  		type: type,
        dismissQueue: false,
        closeWith: ['click','button'],
        timeout: 3000,
  		layout: layout,
  		theme: 'defaultTheme'
  	});
  }