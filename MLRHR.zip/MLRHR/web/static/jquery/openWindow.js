
function openUploadfile(url){
	window.open(url,'','height=600,width=1000,top=200,left=200,toolbar=no,menubar=no,scrollbars=yes,resizeable=no,location=no,status=no');
}