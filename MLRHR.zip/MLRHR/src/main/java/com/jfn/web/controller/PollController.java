package com.jfn.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/")
public class PollController
{
	@RequestMapping(value = "createpoll", method = RequestMethod.GET)
	public String createpoll()
	{
		return "createpoll";
	}
}
