package com.jfn.common.util;

public class Constant {
	/**成功状态码 0 */
	public static final Integer STATUS_SUCCESS = 0;
	/**失败状态码 1 */
	public static final Integer STAUS_FAIL = 1;
	/**状态表示 status */
	public static final String STATUS = "status";
	/**状态信息表示 msg */
	public static final String MSG = "msg";
	/**文件上传路径*/
	public static final String FILE_PATH="../file/";

}
