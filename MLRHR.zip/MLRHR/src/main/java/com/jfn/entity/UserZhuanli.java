package com.jfn.entity;


/**
 * 用户.
 * 
 * @author tong
 */
public class UserZhuanli
{
	private Integer id;
	private String user_id;
	private String date;
	private String name;
	private String jiaose;
	private String type;
	private String other;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getJiaose() {
		return jiaose;
	}
	public void setJiaose(String jiaose) {
		this.jiaose = jiaose;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getOther() {
		return other;
	}
	public void setOther(String other) {
		this.other = other;
	}
	

	
}