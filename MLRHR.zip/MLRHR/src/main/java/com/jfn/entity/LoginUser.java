package com.jfn.entity;

public class LoginUser
{
	private int id;
	private String login_name;
	private String login_pwd;
	private String username;
	public int getId()
	{
		return id;
	}
	public void setId( int id )
	{
		this.id = id;
	}
	public String getLogin_name()
	{
		return login_name;
	}
	public void setLogin_name( String login_name )
	{
		this.login_name = login_name;
	}
	public String getLogin_pwd()
	{
		return login_pwd;
	}
	public void setLogin_pwd( String login_pwd )
	{
		this.login_pwd = login_pwd;
	}
	public String getUsername()
	{
		return username;
	}
	public void setUsername( String username )
	{
		this.username = username;
	}
}
