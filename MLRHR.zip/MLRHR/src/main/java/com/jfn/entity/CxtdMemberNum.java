package com.jfn.entity;

public class CxtdMemberNum {
	public Integer getNum() {
		return num;
	}
	public void setNum(Integer num) {
		this.num = num;
	}
	private Integer id;
	private Integer num;
	private Integer team_id;
	private Integer age_56;
	private Integer age_46_55;
	private Integer age_36_45;
	private Integer age_35;
	private Integer gaoji;
	private Integer fugao;
	private Integer zhongji;
	private Integer z_orther;
	private Integer boshi;
	private Integer shuoshi;
	private Integer benke;
	private Integer x_orther;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getTeam_id() {
		return team_id;
	}
	public void setTeam_id(Integer team_id) {
		this.team_id = team_id;
	}
	public Integer getAge_56() {
		return age_56;
	}
	public void setAge_56(Integer age_56) {
		this.age_56 = age_56;
	}
	public Integer getAge_46_55() {
		return age_46_55;
	}
	public void setAge_46_55(Integer age_46_55) {
		this.age_46_55 = age_46_55;
	}
	public Integer getAge_36_45() {
		return age_36_45;
	}
	public void setAge_36_45(Integer age_36_45) {
		this.age_36_45 = age_36_45;
	}
	public Integer getAge_35() {
		return age_35;
	}
	public void setAge_35(Integer age_35) {
		this.age_35 = age_35;
	}
	public Integer getGaoji() {
		return gaoji;
	}
	public void setGaoji(Integer gaoji) {
		this.gaoji = gaoji;
	}
	public Integer getFugao() {
		return fugao;
	}
	public void setFugao(Integer fugao) {
		this.fugao = fugao;
	}
	public Integer getZhongji() {
		return zhongji;
	}
	public void setZhongji(Integer zhongji) {
		this.zhongji = zhongji;
	}
	public Integer getZ_orther() {
		return z_orther;
	}
	public void setZ_orther(Integer z_orther) {
		this.z_orther = z_orther;
	}
	public Integer getBoshi() {
		return boshi;
	}
	public void setBoshi(Integer boshi) {
		this.boshi = boshi;
	}
	public Integer getShuoshi() {
		return shuoshi;
	}
	public void setShuoshi(Integer shuoshi) {
		this.shuoshi = shuoshi;
	}
	public Integer getBenke() {
		return benke;
	}
	public void setBenke(Integer benke) {
		this.benke = benke;
	}
	public Integer getX_orther() {
		return x_orther;
	}
	public void setX_orther(Integer x_orther) {
		this.x_orther = x_orther;
	}
	@Override
	public String toString() {
		return "CxtdMemberNum [id=" + id + ", num=" + num + ", team_id="
				+ team_id + ", age_56=" + age_56 + ", age_46_55=" + age_46_55
				+ ", age_36_45=" + age_36_45 + ", age_35=" + age_35
				+ ", gaoji=" + gaoji + ", fugao=" + fugao + ", zhongji="
				+ zhongji + ", z_orther=" + z_orther + ", boshi=" + boshi
				+ ", shuoshi=" + shuoshi + ", benke=" + benke + ", x_orther="
				+ x_orther + "]";
	}


}
