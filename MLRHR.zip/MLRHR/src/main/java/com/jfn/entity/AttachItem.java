package com.jfn.entity;

import java.util.Date;

/**
 * 用于显示用户收藏的文件列表
 *
 */
public class AttachItem
{
	private int id;
	private String file_name;
	private Date upload_time; 
	private Date create_time; 
	private String subject;
	
	
	public Date getCreate_time() {
		return create_time;
	}
	public void setCreate_time(Date create_time) {
		this.create_time = create_time;
	}
	
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}

	
	public int getId()
	{
		return id;
	}
	public void setId( int id )
	{
		this.id = id;
	}
	public String getFile_name()
	{
		return file_name;
	}
	public void setFile_name( String file_name )
	{
		this.file_name = file_name;
	}
	public Date getUpload_time()
	{
		return upload_time;
	}
	public void setUpload_time( Date upload_time )
	{
		this.upload_time = upload_time;
	}	
}
