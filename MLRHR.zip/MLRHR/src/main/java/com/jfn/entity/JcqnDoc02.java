package com.jfn.entity;

public class JcqnDoc02 {
	private Integer user_id;
	private Integer serial_number1;
	private String entry_name;
	private String project_number;
	private String funds;
	private String start_stop_time;
	private String project_nature;
	private String role;
	private Integer serial_number2;
	private String award_item_name;
	private String prize_name;
	private String sort;
	private String reward_time;
	private String grant_institution;
	private Integer serial_number3;
	private String thesis_topic;
	private String author_sort;
	private String journal_title;
	private String year_volume_pagenumber;
	private String influence_factor ;
	private String sci_times;
	private String number_total;
	private Integer serial_number4;
	private String patent_name;
	private String grant_number;
	private String inventor_sort;
	private String type;
	private String authorized_time;
	private String authorized_national;
	private Integer serial_number5;
	private String report_name;
	private String meeting_name;
	private String organizers;
	private String meeting_time;
	private String meeting_place;
	private String report_type;
	private Integer serial_number6;
	private String treatise_name;
	private String press;
	private String issuing_country;
	private String year;
	public Integer getUser_id() {
		return user_id;
	}
	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}
	public Integer getSerial_number1() {
		return serial_number1;
	}
	public void setSerial_number1(Integer serial_number1) {
		this.serial_number1 = serial_number1;
	}
	public String getEntry_name() {
		return entry_name;
	}
	public void setEntry_name(String entry_name) {
		this.entry_name = entry_name;
	}
	public String getProject_number() {
		return project_number;
	}
	public void setProject_number(String project_number) {
		this.project_number = project_number;
	}
	public String getFunds() {
		return funds;
	}
	public void setFunds(String funds) {
		this.funds = funds;
	}
	public String getStart_stop_time() {
		return start_stop_time;
	}
	public void setStart_stop_time(String start_stop_time) {
		this.start_stop_time = start_stop_time;
	}
	public String getProject_nature() {
		return project_nature;
	}
	public void setProject_nature(String project_nature) {
		this.project_nature = project_nature;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public Integer getSerial_number2() {
		return serial_number2;
	}
	public void setSerial_number2(Integer serial_number2) {
		this.serial_number2 = serial_number2;
	}
	public String getAward_item_name() {
		return award_item_name;
	}
	public void setAward_item_name(String award_item_name) {
		this.award_item_name = award_item_name;
	}
	public String getPrize_name() {
		return prize_name;
	}
	public void setPrize_name(String prize_name) {
		this.prize_name = prize_name;
	}
	public String getSort() {
		return sort;
	}
	public void setSort(String sort) {
		this.sort = sort;
	}
	public String getReward_time() {
		return reward_time;
	}
	public void setReward_time(String reward_time) {
		this.reward_time = reward_time;
	}
	public String getGrant_institution() {
		return grant_institution;
	}
	public void setGrant_institution(String grant_institution) {
		this.grant_institution = grant_institution;
	}
	public Integer getSerial_number3() {
		return serial_number3;
	}
	public void setSerial_number3(Integer serial_number3) {
		this.serial_number3 = serial_number3;
	}
	public String getThesis_topic() {
		return thesis_topic;
	}
	public void setThesis_topic(String thesis_topic) {
		this.thesis_topic = thesis_topic;
	}
	public String getAuthor_sort() {
		return author_sort;
	}
	public void setAuthor_sort(String author_sort) {
		this.author_sort = author_sort;
	}
	public String getJournal_title() {
		return journal_title;
	}
	public void setJournal_title(String journal_title) {
		this.journal_title = journal_title;
	}
	public String getYear_volume_pagenumber() {
		return year_volume_pagenumber;
	}
	public void setYear_volume_pagenumber(String year_volume_pagenumber) {
		this.year_volume_pagenumber = year_volume_pagenumber;
	}
	public String getInfluence_factor() {
		return influence_factor;
	}
	public void setInfluence_factor(String influence_factor) {
		this.influence_factor = influence_factor;
	}
	public String getSci_times() {
		return sci_times;
	}
	public void setSci_times(String sci_times) {
		this.sci_times = sci_times;
	}
	public String getNumber_total() {
		return number_total;
	}
	public void setNumber_total(String number_total) {
		this.number_total = number_total;
	}
	public Integer getSerial_number4() {
		return serial_number4;
	}
	public void setSerial_number4(Integer serial_number4) {
		this.serial_number4 = serial_number4;
	}
	public String getPatent_name() {
		return patent_name;
	}
	public void setPatent_name(String patent_name) {
		this.patent_name = patent_name;
	}
	public String getGrant_number() {
		return grant_number;
	}
	public void setGrant_number(String grant_number) {
		this.grant_number = grant_number;
	}
	public String getInventor_sort() {
		return inventor_sort;
	}
	public void setInventor_sort(String inventor_sort) {
		this.inventor_sort = inventor_sort;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getAuthorized_time() {
		return authorized_time;
	}
	public void setAuthorized_time(String authorized_time) {
		this.authorized_time = authorized_time;
	}
	public String getAuthorized_national() {
		return authorized_national;
	}
	public void setAuthorized_national(String authorized_national) {
		this.authorized_national = authorized_national;
	}
	public Integer getSerial_number5() {
		return serial_number5;
	}
	public void setSerial_number5(Integer serial_number5) {
		this.serial_number5 = serial_number5;
	}
	public String getReport_name() {
		return report_name;
	}
	public void setReport_name(String report_name) {
		this.report_name = report_name;
	}
	public String getMeeting_name() {
		return meeting_name;
	}
	public void setMeeting_name(String meeting_name) {
		this.meeting_name = meeting_name;
	}
	public String getOrganizers() {
		return organizers;
	}
	public void setOrganizers(String organizers) {
		this.organizers = organizers;
	}
	public String getMeeting_time() {
		return meeting_time;
	}
	public void setMeeting_time(String meeting_time) {
		this.meeting_time = meeting_time;
	}
	public String getMeeting_place() {
		return meeting_place;
	}
	public void setMeeting_place(String meeting_place) {
		this.meeting_place = meeting_place;
	}
	public String getReport_type() {
		return report_type;
	}
	public void setReport_type(String report_type) {
		this.report_type = report_type;
	}
	public Integer getSerial_number6() {
		return serial_number6;
	}
	public void setSerial_number6(Integer serial_number6) {
		this.serial_number6 = serial_number6;
	}
	public String getTreatise_name() {
		return treatise_name;
	}
	public void setTreatise_name(String treatise_name) {
		this.treatise_name = treatise_name;
	}
	public String getPress() {
		return press;
	}
	public void setPress(String press) {
		this.press = press;
	}
	public String getIssuing_country() {
		return issuing_country;
	}
	public void setIssuing_country(String issuing_country) {
		this.issuing_country = issuing_country;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public JcqnDoc02(Integer user_id, Integer serial_number1,
			String entry_name, String project_number, String funds,
			String start_stop_time, String project_nature, String role,
			Integer serial_number2, String award_item_name, String prize_name,
			String sort, String reward_time, String grant_institution,
			Integer serial_number3, String thesis_topic, String author_sort,
			String journal_title, String year_volume_pagenumber,
			String influence_factor, String sci_times, String number_total,
			Integer serial_number4, String patent_name, String grant_number,
			String inventor_sort, String type, String authorized_time,
			String authorized_national, Integer serial_number5,
			String report_name, String meeting_name, String organizers,
			String meeting_time, String meeting_place, String report_type,
			Integer serial_number6, String treatise_name, String press,
			String issuing_country, String year) {
		super();
		this.user_id = user_id;
		this.serial_number1 = serial_number1;
		this.entry_name = entry_name;
		this.project_number = project_number;
		this.funds = funds;
		this.start_stop_time = start_stop_time;
		this.project_nature = project_nature;
		this.role = role;
		this.serial_number2 = serial_number2;
		this.award_item_name = award_item_name;
		this.prize_name = prize_name;
		this.sort = sort;
		this.reward_time = reward_time;
		this.grant_institution = grant_institution;
		this.serial_number3 = serial_number3;
		this.thesis_topic = thesis_topic;
		this.author_sort = author_sort;
		this.journal_title = journal_title;
		this.year_volume_pagenumber = year_volume_pagenumber;
		this.influence_factor = influence_factor;
		this.sci_times = sci_times;
		this.number_total = number_total;
		this.serial_number4 = serial_number4;
		this.patent_name = patent_name;
		this.grant_number = grant_number;
		this.inventor_sort = inventor_sort;
		this.type = type;
		this.authorized_time = authorized_time;
		this.authorized_national = authorized_national;
		this.serial_number5 = serial_number5;
		this.report_name = report_name;
		this.meeting_name = meeting_name;
		this.organizers = organizers;
		this.meeting_time = meeting_time;
		this.meeting_place = meeting_place;
		this.report_type = report_type;
		this.serial_number6 = serial_number6;
		this.treatise_name = treatise_name;
		this.press = press;
		this.issuing_country = issuing_country;
		this.year = year;
	}
	public JcqnDoc02() {
		super();
	}

}
