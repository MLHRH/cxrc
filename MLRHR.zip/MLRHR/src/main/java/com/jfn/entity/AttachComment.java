package com.jfn.entity;

import java.util.Date;

public class AttachComment
{
	private int id;
	private int userid;
	private int attachid;
	private Date comment_time;
	private String comment;
	private String username;
	public String getUsername()
	{
		return username;
	}
	public void setUsername( String username )
	{
		this.username = username;
	}
	public int getId()
	{
		return id;
	}
	public void setId( int id )
	{
		this.id = id;
	}
	public int getUserid()
	{
		return userid;
	}
	public void setUserid( int userid )
	{
		this.userid = userid;
	}
	public int getAttachid()
	{
		return attachid;
	}
	public void setAttachid( int attachid )
	{
		this.attachid = attachid;
	}
	public Date getComment_time()
	{
		return comment_time;
	}
	public void setComment_time( Date comment_time )
	{
		this.comment_time = comment_time;
	}
	public String getComment()
	{
		return comment;
	}
	public void setComment( String comment )
	{
		this.comment = comment;
	}
	
	
}
