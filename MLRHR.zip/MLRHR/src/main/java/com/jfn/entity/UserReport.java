package com.jfn.entity;


/**
 * 用户.
 * 
 * @author tongdehui
 */
public class UserReport
{
	private Integer id;
	private String user_id;
	private String date;
	private String name;
	private String content_summary;
	private String situation;
	private String isAlone;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContent_summary() {
		return content_summary;
	}
	public void setContent_summary(String content_summary) {
		this.content_summary = content_summary;
	}
	public String getSituation() {
		return situation;
	}
	public void setSituation(String situation) {
		this.situation = situation;
	}
	public String getIsAlone() {
		return isAlone;
	}
	public void setIsAlone(String isAlone) {
		this.isAlone = isAlone;
	}

	
	

	
}