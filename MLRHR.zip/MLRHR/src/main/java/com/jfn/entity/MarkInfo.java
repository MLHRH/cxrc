package com.jfn.entity;

public class MarkInfo {
	//基本条件
	private String  typebase_info;
	//基本条件_参考分值
	private Integer base_info_score;
	//个人能力/团队构成
	private String personal_ability;
	//个人能力/团队构成_参考分值
	private Integer personal_ability_score;
	//研发业绩
	private String research_performance;
	//研发业绩_参考分值
	private Integer research_performance_score;
	//研发规划
	private String development_plan;
	//研发规划_参考分值
	private Integer development_plan_score;
	//条件保障
	private String security;
	//条件保障_参考分值
	private Integer security_score;
	public String getTypebase_info() {
		return typebase_info;
	}
	public void setTypebase_info(String typebase_info) {
		this.typebase_info = typebase_info;
	}
	public Integer getBase_info_score() {
		return base_info_score;
	}
	public void setBase_info_score(Integer base_info_score) {
		this.base_info_score = base_info_score;
	}
	public String getPersonal_ability() {
		return personal_ability;
	}
	public void setPersonal_ability(String personal_ability) {
		this.personal_ability = personal_ability;
	}
	public Integer getPersonal_ability_score() {
		return personal_ability_score;
	}
	public void setPersonal_ability_score(Integer personal_ability_score) {
		this.personal_ability_score = personal_ability_score;
	}
	public String getResearch_performance() {
		return research_performance;
	}
	public void setResearch_performance(String research_performance) {
		this.research_performance = research_performance;
	}
	public Integer getResearch_performance_score() {
		return research_performance_score;
	}
	public void setResearch_performance_score(Integer research_performance_score) {
		this.research_performance_score = research_performance_score;
	}
	public String getDevelopment_plan() {
		return development_plan;
	}
	public void setDevelopment_plan(String development_plan) {
		this.development_plan = development_plan;
	}
	public Integer getDevelopment_plan_score() {
		return development_plan_score;
	}
	public void setDevelopment_plan_score(Integer development_plan_score) {
		this.development_plan_score = development_plan_score;
	}
	public String getSecurity() {
		return security;
	}
	public void setSecurity(String security) {
		this.security = security;
	}
	public Integer getSecurity_score() {
		return security_score;
	}
	public void setSecurity_score(Integer security_score) {
		this.security_score = security_score;
	}


}
