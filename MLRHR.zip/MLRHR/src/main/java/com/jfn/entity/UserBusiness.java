package com.jfn.entity;

/**
 * 用户.
 * 
 * @author tongdehui
 */
public class UserBusiness {

	private Integer id;
	private Integer user_id;
	private String autobiography;
	private String chuangxin;
	private String yijian_1;
	private String yijian_2;
	private String yijian_3;
	private String fuzeren_1;
	private String fuzeren_2;
	private String fuzeren_3;
	private String fengpi;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAutobiography() {
		return autobiography;
	}

	public void setAutobiography(String autobiography) {
		this.autobiography = autobiography;
	}

	public Integer getUser_id() {
		return user_id;
	}

	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}

	public String getChuangxin() {
		return chuangxin;
	}

	public void setChuangxin(String chuangxin) {
		this.chuangxin = chuangxin;
	}

	public String getYijian_1() {
		return yijian_1;
	}

	public void setYijian_1(String yijian_1) {
		this.yijian_1 = yijian_1;
	}

	public String getYijian_2() {
		return yijian_2;
	}

	public void setYijian_2(String yijian_2) {
		this.yijian_2 = yijian_2;
	}

	public String getYijian_3() {
		return yijian_3;
	}

	public void setYijian_3(String yijian_3) {
		this.yijian_3 = yijian_3;
	}

	public String getFuzeren_1() {
		return fuzeren_1;
	}

	public void setFuzeren_1(String fuzeren_1) {
		this.fuzeren_1 = fuzeren_1;
	}

	public String getFuzeren_2() {
		return fuzeren_2;
	}

	public void setFuzeren_2(String fuzeren_2) {
		this.fuzeren_2 = fuzeren_2;
	}

	public String getFuzeren_3() {
		return fuzeren_3;
	}

	public void setFuzeren_3(String fuzeren_3) {
		this.fuzeren_3 = fuzeren_3;
	}

	public String getFengpi() {
		return fengpi;
	}

	public void setFengpi(String fengpi) {
		this.fengpi = fengpi;
	}

}