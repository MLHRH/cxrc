package com.jfn.entity;

/**
 * 用户.
 * 
 * @author yangjsh
 * @remarks 2015-5-14 下午5:43:08 佟德慧增加user其他信息变量
 */
public class UserBaseInfor {
	private Integer id;
	private Integer user_id;
	private String former_name;
	private String gender;
	private String minzu;
	private String birthday;
	private String health;
	private String chushengdi;
	private String canjiashijian;
	private String zhengzhi;
	private String yuyan;
	private String jisuanji;
	private String minzhudangpai;
	private String shehuijianzhi;
	private String current_zhicheng;
	private String current_zhicheng_date;
	private String congshizhuanye;
	private String renzhizige;
	private String shenpidanwei;
	private String shenpishijian;
	private String xingzhengzhiwu;
	private String xingzhengshijian;
	private String kaohe;
	private String tiaojian;
	private String yingyu;
	private String gongzi;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFormer_name() {
		return former_name;
	}

	public void setFormer_name(String former_name) {
		this.former_name = former_name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getMinzu() {
		return minzu;
	}

	public void setMinzu(String minzu) {
		this.minzu = minzu;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getHealth() {
		return health;
	}

	public void setHealth(String health) {
		this.health = health;
	}

	public String getChushengdi() {
		return chushengdi;
	}

	public void setChushengdi(String chushengdi) {
		this.chushengdi = chushengdi;
	}

	public String getCanjiashijian() {
		return canjiashijian;
	}

	public void setCanjiashijian(String canjiashijian) {
		this.canjiashijian = canjiashijian;
	}

	public String getZhengzhi() {
		return zhengzhi;
	}

	public void setZhengzhi(String zhengzhi) {
		this.zhengzhi = zhengzhi;
	}

	public String getYuyan() {
		return yuyan;
	}

	public void setYuyan(String yuyan) {
		this.yuyan = yuyan;
	}

	public String getJisuanji() {
		return jisuanji;
	}

	public void setJisuanji(String jisuanji) {
		this.jisuanji = jisuanji;
	}

	public String getMinzhudangpai() {
		return minzhudangpai;
	}

	public void setMinzhudangpai(String minzhudangpai) {
		this.minzhudangpai = minzhudangpai;
	}

	public String getShehuijianzhi() {
		return shehuijianzhi;
	}

	public void setShehuijianzhi(String shehuijianzhi) {
		this.shehuijianzhi = shehuijianzhi;
	}

	public String getCurrent_zhicheng() {
		return current_zhicheng;
	}

	public void setCurrent_zhicheng(String current_zhicheng) {
		this.current_zhicheng = current_zhicheng;
	}

	public String getCurrent_zhicheng_date() {
		return current_zhicheng_date;
	}

	public void setCurrent_zhicheng_date(String current_zhicheng_date) {
		this.current_zhicheng_date = current_zhicheng_date;
	}

	public Integer getUser_id() {
		return user_id;
	}

	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}

	public String getCongshizhuanye() {
		return congshizhuanye;
	}

	public void setCongshizhuanye(String congshizhuanye) {
		this.congshizhuanye = congshizhuanye;
	}

	public String getRenzhizige() {
		return renzhizige;
	}

	public void setRenzhizige(String renzhizige) {
		this.renzhizige = renzhizige;
	}

	public String getShenpidanwei() {
		return shenpidanwei;
	}

	public void setShenpidanwei(String shenpidanwei) {
		this.shenpidanwei = shenpidanwei;
	}

	public String getShenpishijian() {
		return shenpishijian;
	}

	public void setShenpishijian(String shenpishijian) {
		this.shenpishijian = shenpishijian;
	}

	public String getXingzhengzhiwu() {
		return xingzhengzhiwu;
	}

	public void setXingzhengzhiwu(String xingzhengzhiwu) {
		this.xingzhengzhiwu = xingzhengzhiwu;
	}

	public String getXingzhengshijian() {
		return xingzhengshijian;
	}

	public void setXingzhengshijian(String xingzhengshijian) {
		this.xingzhengshijian = xingzhengshijian;
	}

	public String getKaohe() {
		return kaohe;
	}

	public void setKaohe(String kaohe) {
		this.kaohe = kaohe;
	}

	public String getTiaojian() {
		return tiaojian;
	}

	public void setTiaojian(String tiaojian) {
		this.tiaojian = tiaojian;
	}

	public String getYingyu() {
		return yingyu;
	}

	public void setYingyu(String yingyu) {
		this.yingyu = yingyu;
	}

	public String getGongzi() {
		return gongzi;
	}

	public void setGongzi(String gongzi) {
		this.gongzi = gongzi;
	}

}