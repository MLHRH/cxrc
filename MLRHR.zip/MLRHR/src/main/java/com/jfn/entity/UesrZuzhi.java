package com.jfn.entity;

public class UesrZuzhi {
	
	private Integer userId;
	/*
	 * 日期*/
	private String date;
	/*
	 * 姓名*/
	private String name;
	/*
	 * 角色*/
	private String jiaose;
	/*
	 * 类型*/
	private String type;
	/*
	 * 其他*/
	private String other;
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getJiaose() {
		return jiaose;
	}
	public void setJiaose(String jiaose) {
		this.jiaose = jiaose;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getOther() {
		return other;
	}
	public void setOther(String other) {
		this.other = other;
	}
	

}
