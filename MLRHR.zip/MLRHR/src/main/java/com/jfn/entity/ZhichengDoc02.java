package com.jfn.entity;

public class ZhichengDoc02 {

	private int id;
	private int user_id;
	private int file_type_01;
	private int file_type_02;
	private int file_type_03;
	private int file_type_04;
	private int file_type_05;
	private int file_type_06;
	private int file_type_07;
	private int file_type_08;
	private String series_name; 
	private String professional_name; 
	private String qualification_name;
	private String user_name;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public int getFile_type_01() {
		return file_type_01;
	}
	public void setFile_type_01(int file_type_01) {
		this.file_type_01 = file_type_01;
	}
	public int getFile_type_02() {
		return file_type_02;
	}
	public void setFile_type_02(int file_type_02) {
		this.file_type_02 = file_type_02;
	}
	public int getFile_type_03() {
		return file_type_03;
	}
	public void setFile_type_03(int file_type_03) {
		this.file_type_03 = file_type_03;
	}
	public int getFile_type_04() {
		return file_type_04;
	}
	public void setFile_type_04(int file_type_04) {
		this.file_type_04 = file_type_04;
	}
	public int getFile_type_05() {
		return file_type_05;
	}
	public void setFile_type_05(int file_type_05) {
		this.file_type_05 = file_type_05;
	}
	public int getFile_type_06() {
		return file_type_06;
	}
	public void setFile_type_06(int file_type_06) {
		this.file_type_06 = file_type_06;
	}
	public int getFile_type_07() {
		return file_type_07;
	}
	public void setFile_type_07(int file_type_07) {
		this.file_type_07 = file_type_07;
	}
	public int getFile_type_08() {
		return file_type_08;
	}
	public void setFile_type_08(int file_type_08) {
		this.file_type_08 = file_type_08;
	}
	public String getSeries_name() {
		return series_name;
	}
	public void setSeries_name(String series_name) {
		this.series_name = series_name;
	}
	
	public String getProfessional_name() {
		return professional_name;
	}
	public void setProfessional_name(String professional_name) {
		this.professional_name = professional_name;
	}
	public String getQualification_name() {
		return qualification_name;
	}
	public void setQualification_name(String qualification_name) {
		this.qualification_name = qualification_name;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	} 
	
}
