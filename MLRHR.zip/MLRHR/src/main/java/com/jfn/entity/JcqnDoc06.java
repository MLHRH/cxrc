package com.jfn.entity;

public class JcqnDoc06 {
private int user_id;
private int id;
private String work_unit_opinion;
private String recommended_unit_opinion;
public int getUser_id() {
	return user_id;
}
public void setUser_id(int user_id) {
	this.user_id = user_id;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getWork_unit_opinion() {
	return work_unit_opinion;
}
public void setWork_unit_opinion(String work_unit_opinion) {
	this.work_unit_opinion = work_unit_opinion;
}
public String getRecommended_unit_opinion() {
	return recommended_unit_opinion;
}
public void setRecommended_unit_opinion(String recommended_unit_opinion) {
	this.recommended_unit_opinion = recommended_unit_opinion;
}

}
