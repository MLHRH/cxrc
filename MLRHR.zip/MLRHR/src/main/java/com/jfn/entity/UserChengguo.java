package com.jfn.entity;

/**
 * 用户.
 * 
 * @author chenzhu
 */
public class UserChengguo {
	private Integer id;
	private String user_id;
	private String cg_date;
	private String cg_name;
	private String cg_jieshao;
	private String jiaose;
	private String type;
	private String yingxiangyinzi;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getCg_date() {
		return cg_date;
	}

	public void setCg_date(String cg_date) {
		this.cg_date = cg_date;
	}

	public String getCg_jieshao() {
		return cg_jieshao;
	}

	public void setCg_jieshao(String cg_jieshao) {
		this.cg_jieshao = cg_jieshao;
	}

	public String getJiaose() {
		return jiaose;
	}

	public void setJiaose(String jiaose) {
		this.jiaose = jiaose;
	}

	public String getCg_name() {
		return cg_name;
	}

	public void setCg_name(String cg_name) {
		this.cg_name = cg_name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getYingxiangyinzi() {
		return yingxiangyinzi;
	}

	public void setYingxiangyinzi(String yingxiangyinzi) {
		this.yingxiangyinzi = yingxiangyinzi;
	}

}