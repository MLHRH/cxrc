package com.jfn.entity;

public class ZhichengDoc08 {

	private int id;
	private int user_id;
	private String user_name;
	private String xuewei;
	private String xueli;
	private String tuijian_name;
	private String tuijian_zhiwu;
	private String tuijian_danwei;
	private String tuijian_liyou;
	private String tuijian_zhuanjia;
	private String tuijian_name_2;
	private String tuijian_zhiwu_2;
	private String tuijian_danwei_2;
	private String tuijian_liyou_2;
	private String tuijian_zhuanjia_2;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getXuewei() {
		return xuewei;
	}

	public void setXuewei(String xuewei) {
		this.xuewei = xuewei;
	}

	public String getXueli() {
		return xueli;
	}

	public void setXueli(String xueli) {
		this.xueli = xueli;
	}

	public String getTuijian_name() {
		return tuijian_name;
	}

	public void setTuijian_name(String tuijian_name) {
		this.tuijian_name = tuijian_name;
	}

	public String getTuijian_zhiwu() {
		return tuijian_zhiwu;
	}

	public void setTuijian_zhiwu(String tuijian_zhiwu) {
		this.tuijian_zhiwu = tuijian_zhiwu;
	}

	public String getTuijian_danwei() {
		return tuijian_danwei;
	}

	public void setTuijian_danwei(String tuijian_danwei) {
		this.tuijian_danwei = tuijian_danwei;
	}

	public String getTuijian_liyou() {
		return tuijian_liyou;
	}

	public void setTuijian_liyou(String tuijian_liyou) {
		this.tuijian_liyou = tuijian_liyou;
	}

	public String getTuijian_zhuanjia() {
		return tuijian_zhuanjia;
	}

	public void setTuijian_zhuanjia(String tuijian_zhuanjia) {
		this.tuijian_zhuanjia = tuijian_zhuanjia;
	}

	public String getTuijian_name_2() {
		return tuijian_name_2;
	}

	public void setTuijian_name_2(String tuijian_name_2) {
		this.tuijian_name_2 = tuijian_name_2;
	}

	public String getTuijian_zhiwu_2() {
		return tuijian_zhiwu_2;
	}

	public void setTuijian_zhiwu_2(String tuijian_zhiwu_2) {
		this.tuijian_zhiwu_2 = tuijian_zhiwu_2;
	}

	public String getTuijian_danwei_2() {
		return tuijian_danwei_2;
	}

	public void setTuijian_danwei_2(String tuijian_danwei_2) {
		this.tuijian_danwei_2 = tuijian_danwei_2;
	}

	public String getTuijian_liyou_2() {
		return tuijian_liyou_2;
	}

	public void setTuijian_liyou_2(String tuijian_liyou_2) {
		this.tuijian_liyou_2 = tuijian_liyou_2;
	}

	public String getTuijian_zhuanjia_2() {
		return tuijian_zhuanjia_2;
	}

	public void setTuijian_zhuanjia_2(String tuijian_zhuanjia_2) {
		this.tuijian_zhuanjia_2 = tuijian_zhuanjia_2;
	}

}
