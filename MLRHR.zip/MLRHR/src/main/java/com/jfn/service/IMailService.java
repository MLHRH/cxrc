package com.jfn.service;

import org.springframework.mail.SimpleMailMessage; 

public interface IMailService
{
	void send( SimpleMailMessage smm );
}
