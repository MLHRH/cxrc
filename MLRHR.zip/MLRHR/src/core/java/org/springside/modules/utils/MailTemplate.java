package org.springside.modules.utils;

/**
 * 邮件模版类
 * 
 * @author stanley huang
 *
 */
public class MailTemplate {

	public static String MAIL_GET_PWD_TEMPLATE = "";
	
	public static String MAIL_GET_PWD_SUBJECT = "找回密码";
	
	public static String MAIL_GET_PWD_BODY = "欢迎使用找回密码功能。"
			+ "请根据以下链接重置您的密码。"
			+"如果您并未发过此请求，则可能是因为其他用户在尝试重设密码时误输入了您的电子邮件"
			+ "地址而使您收到这封邮件，那么您可以放心的忽略此邮件，无需进一步采取任何操作。"
			+ "新密码为:";

	public static String getMAIL_GET_PWD_TEMPLATE() {
		return MAIL_GET_PWD_TEMPLATE;
	}

	public static void setMAIL_GET_PWD_TEMPLATE(String mAIL_GET_PWD_TEMPLATE) {
		MAIL_GET_PWD_TEMPLATE = mAIL_GET_PWD_TEMPLATE;
	}

	public static String getMAIL_GET_PWD_SUBJECT() {
		return MAIL_GET_PWD_SUBJECT;
	}

	public static void setMAIL_GET_PWD_SUBJECT(String mAIL_GET_PWD_SUBJECT) {
		MAIL_GET_PWD_SUBJECT = mAIL_GET_PWD_SUBJECT;
	}

	public static String getMAIL_GET_PWD_BODY() {
		return MAIL_GET_PWD_BODY;
	}

	public static void setMAIL_GET_PWD_BODY(String mAIL_GET_PWD_BODY) {
		MAIL_GET_PWD_BODY = mAIL_GET_PWD_BODY;
	}
	
	
	
}
